def main(event, content):
    print(event)
    return event
