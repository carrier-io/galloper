
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.16.3'
version = '1.16.3'
full_version = '1.16.3'
git_revision = '08b17aee272fb3f64bb0e5e96e0376c0f9fd9424'
release = True

if not release:
    version = full_version
